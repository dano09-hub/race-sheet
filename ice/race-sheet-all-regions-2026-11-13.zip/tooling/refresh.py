#!/usr/bin/env python3
"""Refresh the page in one command: scrape, rebuild, stage for deploy.

    python3 tooling/refresh.py            # today + tomorrow UK, today US, today results
    python3 tooling/refresh.py --days 3   # widen the UK window

Steps
  1. UK racecards  -> RACE_CARDS (today), CARDS_FRI (tomorrow)
  2. US entries    -> CARDS_US (today)
  3. settled results -> data/YYYY-MM-DD.json (feeds the back-test dataset)
  4. rewrite the three JS blocks inside index.html
  5. copy to dist/public/index.html

A block that scrapes empty is left untouched, so a blocked or quiet day can
never wipe a card that already works.
"""

import datetime as dt
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from parse_cards import get, parse_course_page          # noqa: E402
from scrape_us import get as us_get, parse_track        # noqa: E402
import scrape_results                                   # noqa: E402
try:
    import scrape_hk                                    # noqa: E402
except Exception:                                       # pragma: no cover
    scrape_hk = None

ROOT = os.path.join(HERE, "..")
INDEX = os.path.join(ROOT, "index.html")

RUNNER_KEYS = ("horse", "odds", "form", "or", "rpr", "ts", "weight", "days",
               "course", "distance", "going", "jp", "tp", "tips", "naps")


def js(s):
    return json.dumps(str(s), ensure_ascii=False)


def serialise(cards, comment):
    out = [f"  // {comment}"]
    name = "BLOCK"
    body = []
    for c in cards:
        runners = ",\n".join(
            "        {" + ", ".join(f"{k}:{js(r.get(k, ''))}" for k in RUNNER_KEYS) + "}"
            for r in c["runners"])
        head = (f'      id: {js(c["id"])}, label: {js(c["label"])}, course: {js(c["course"])}, '
                f'time: {js(c["time"])},\n      day: {js(c["day"])}, region: {js(c["region"])},')
        if c.get("iso"):
            head += f'\n      iso: {js(c["iso"])},'
        body.append("    {\n" + head +
                    f'\n      race: {js(c["race"])}, going: {js(c["going"])}, '
                    f'klass: {js(c["klass"])}, note: {js(c.get("note", ""))},\n'
                    "      runners: [\n" + runners + "\n      ]\n    }")
    return out, body


def uk_day(date_iso):
    d = dt.date.fromisoformat(date_iso)
    slug_date = d.strftime("%d-%m-%y")
    index = get(f"https://www.horseracing.net/racecards/{slug_date}")
    slugs = sorted(set(re.findall(rf'href="/([a-z0-9-]+)/{re.escape(slug_date)}"', index)))
    cards = []
    for slug in slugs:
        page = get(f"https://www.horseracing.net/{slug}/{slug_date}")
        if not page:
            continue
        course = slug.replace("-", " ").title()
        for c in parse_course_page(page, course, slug_date):
            title = c["race"]
            c["label"] = (title[:44] + "…") if len(title) > 45 else title
            c["day"] = date_iso
            c["region"] = "GB"
            cards.append(c)
    return cards


def us_day(date_iso):
    day = us_get(f"https://entries.horseracingnation.com/entries-results/{date_iso}")
    slugs = sorted(set(re.findall(rf'href="/entries-results/([a-z0-9-]+)/{date_iso}"', day)))
    cards = []
    for slug in slugs:
        page = us_get(f"https://entries.horseracingnation.com/entries-results/{slug}/{date_iso}")
        course = slug.replace("-", " ").title()
        for c in parse_track(page, course, date_iso):
            c["day"] = date_iso
            c["region"] = "US"
            cards.append(c)
    return cards


def hk_day(date_iso):
    """Sha Tin / Happy Valley card from the HKJC gateway (plain HTTP)."""
    if scrape_hk is None:
        return []
    try:
        payload = scrape_hk.fetch(date_iso.replace("-", "/"))
        return scrape_hk.cards(payload, date_iso)
    except Exception as e:
        print(f"  HK: {e}")
        return []


def au_day():
    """Australian cards are harvested through a browser (Cloudflare); refresh.py
    just picks up the file that harvest leaves behind."""
    path = os.path.join(ROOT, "data", "au_cards.json")
    if not os.path.exists(path):
        return []
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def archive(iso, sets):
    """Keep the pre-race card for the day, so results can be scored against it later."""
    import os
    d = os.path.join(ROOT, "data", "cards")
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, f"{iso}.json")
    payload = {k: v for k, v in sets.items()}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f)
    total = sum(len(v) for v in payload.values())
    print(f"  archived:    {total} cards -> data/cards/{iso}.json")


def replace_block(html, name, body):
    pattern = re.compile(rf"  var {name} = \[.*?\n  \];", re.S)
    if not pattern.search(html):
        raise SystemExit(f"could not find {name} in index.html")
    return pattern.sub(lambda m: f"  var {name} = [\n" + ",\n".join(body) + "\n  ];", html, count=1)


def main():
    days = 2
    for a in sys.argv[1:]:
        if a.startswith("--days"):
            days = int(a.split("=")[1])

    today = dt.date.today()
    iso = today.isoformat()

    print(f"refreshing {iso}")
    uk_today = uk_day(iso)
    print(f"  UK today:    {len(uk_today)} races")
    uk_tomorrow = uk_day((today + dt.timedelta(days=1)).isoformat())
    print(f"  UK tomorrow: {len(uk_tomorrow)} races")
    us = us_day(iso)
    print(f"  US today:    {len(us)} races")
    hk = hk_day(iso)
    print(f"  HK today:    {len(hk)} races")

    try:
        slug_date = today.strftime("%d-%m-%y")
        _, meetings = scrape_results.fetch_day(slug_date)
        if meetings:
            path, races, runners = scrape_results.to_disk(slug_date, meetings)
            print(f"  results:     {races} races / {runners} runners -> {os.path.basename(path)}")
    except Exception as e:
        print(f"  results:     skipped ({e})")

    au = au_day()
    print(f"  AU card:     {len(au)} races")
    archive(iso, {"GB": uk_today, "GB_tomorrow": uk_tomorrow, "US": us, "HK": hk, "AU": au})

    html = open(INDEX, encoding="utf-8").read()
    for name, cards, comment in (
        ("RACE_CARDS", uk_today, f"UK cards, {iso}"),
        ("CARDS_FRI", uk_tomorrow, f"UK cards, {(today + dt.timedelta(days=1)).isoformat()}"),
        ("CARDS_US", us, f"US cards, {iso}"),
        ("CARDS_HK", hk, f"Hong Kong cards, {iso}"),
    ):
        if not cards:
            print(f"  {name}: nothing scraped, left as-is")
            continue
        head, body = serialise(cards, comment)
        html = replace_block(html, name, head + body)

    open(INDEX, "w", encoding="utf-8").write(html)
    os.makedirs(os.path.join(ROOT, "dist", "public"), exist_ok=True)
    open(os.path.join(ROOT, "dist", "public", "index.html"), "w", encoding="utf-8").write(html)
    print(f"  wrote index.html + dist ({len(html.encode())} bytes)")
    print("done — deploy dist/ to publish")


if __name__ == "__main__":
    main()
